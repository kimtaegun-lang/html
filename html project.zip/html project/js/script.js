window.onload=function(){ 
var title = document.getElementById('title');
        title.style.color="red";
};